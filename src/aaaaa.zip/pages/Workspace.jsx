import Header from "../components/Header"
import Footer from "../components/Footer"
import "../style/Workspace.css"

function NaoEncontrado(){
    return(
        <div className="whole-wrapper">
            <Header />
            
            <main className="workspace">
                <button>+Novo caderno</button>
                <p>Você até agora não tem um caderno</p>
            </main>

            <Footer />
        </div>
    )
}

export default NaoEncontrado